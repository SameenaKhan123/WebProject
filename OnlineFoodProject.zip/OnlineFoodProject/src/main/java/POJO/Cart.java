package POJO;

public class Cart 
{
	private int cartid;
	private int foodid;
	private String cEmail;
	private int quantity;
	private String foodName;
	private double foodPrice;
	private double totalPrice;
	
	//Constructor using fields
	public Cart(int cartid, int foodid, String cEmail, int quantity, String foodName, double foodPrice) {
		super();
		this.cartid = cartid;
		this.foodid = foodid;
		this.cEmail = cEmail;
		this.quantity = quantity;
		this.foodName = foodName;
		this.foodPrice = foodPrice;
	}

	//Constructor 
	public Cart()
	{

	}

	@Override
	public String toString() {
		return "Cart [cartid=" + cartid + ", foodid=" + foodid + ", cEmail=" + cEmail + ", quantity=" + quantity
				+ ", foodName=" + foodName + ", foodPrice=" + foodPrice + ", totalPrice=" + totalPrice + "]";
	}

	public int getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public int getFoodid() {
		return foodid;
	}

	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}

	public String getcEmail() {
		return cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public double getFoodPrice() {
		return foodPrice;
	}

	public void setFoodPrice(double foodPrice) {
		this.foodPrice = foodPrice;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	

	
}
