package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Impl.CartDaoImpl;
import Impl.FoodDaoImpl;
import POJO.Cart;
import POJO.Food;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private int cartid;
	private int foodid;
	private String cEmail;
	private int quantity;
	private String foodName;
	private double foodPrice;
	private double totalPrice;
	
	Cart c;
	List<Cart> clist;
	CartDaoImpl cimpl=new CartDaoImpl();
	List<Food> flist;
	
	HttpSession session;
	RequestDispatcher rd;
	
	Boolean flag;
	
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String process=request.getParameter("process");
		session=request.getSession();
		
		if(process!=null && process.equals("addToCart")) {
			
			
			foodid=Integer.parseInt(request.getParameter("foodid"));
			
			flag=cimpl.getFoodIdFromCart(foodid);
			
			
			quantity=1;
			
			c=new Cart();
			c.setFoodid(foodid);
			c.setQuantity(quantity);
			cEmail=(String)session.getAttribute("username");
			c.setcEmail(cEmail);
			
			flag=cimpl.addToCart(c);
			if(flag) {
				
				request.setAttribute("msg", "1 item added to cart");
				
				
			}
			else {
				
				request.setAttribute("errorMsg", "Error while adding your item to cart!!!");
				
			}
			
			flist=new FoodDaoImpl().getAllFood();
			session.setAttribute("flist", flist);
			
			rd=request.getRequestDispatcher("FoodList.jsp");
			rd.forward(request, response);
			
		}
		
		else if(process!=null && process.equals("showMyCart")) {
			String email=(String)session.getAttribute("username");
			
			clist=cimpl.searchCartByEmailId(email);
			
			if(clist==null || clist.isEmpty()) {
				
				request.setAttribute("errorMsg", "Your cart is empty...");
				flist=new FoodDaoImpl().getAllFood();
				session.setAttribute("flist", flist);
				
				rd=request.getRequestDispatcher("FoodList.jsp");
				rd.forward(request, response);
			}
			else {
				
				session.setAttribute("clist", clist);
				response.sendRedirect("CartList.jsp");
			}
		}
		
		else if(process!=null && process.equals("clearCart")) {
			
			cEmail=(String)session.getAttribute("username");
			flag=cimpl.deleteCartByEmail(cEmail);
			if(flag) {
				request.setAttribute("msg", "Your cart is now empty!!");
				flist=new FoodDaoImpl().getAllFood();
				session.setAttribute("flist", flist);
				
				rd=request.getRequestDispatcher("FoodList.jsp");
				rd.forward(request, response);
			}
			else {
				
				request.setAttribute("errorMsg", "Could not clear the cart!! Please try again");
				clist=cimpl.searchCartByEmailId(cEmail);
				session.setAttribute("clist", clist);
				
				rd=request.getRequestDispatcher("CartList.jsp");
				rd.forward(request, response);
			}
		}
		
		else if(process!=null && process.equals("deleteCartItem")) {
			
			cartid=Integer.parseInt(request.getParameter("cartid"));
			
			flag=cimpl.deleteCartById(cartid);
			if(flag) {
				
				request.setAttribute("msg", "Item deleted from cart");
				
			}
			else {
				request.setAttribute("errorMsg", "Could not delete this item. Please try again!!!");
				
			}
			clist=cimpl.searchCartByEmailId(cEmail);
			
			if(clist==null || clist.isEmpty()) {
				
				request.setAttribute("errorMsg", "Your cart is empty...");
				flist=new FoodDaoImpl().getAllFood();
				session.setAttribute("flist", flist);
				
				rd=request.getRequestDispatcher("FoodList.jsp");
				rd.forward(request, response);
			}
			
			else {
			session.setAttribute("clist", clist);
			
			rd=request.getRequestDispatcher("CartList.jsp");
			rd.forward(request, response);
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String process=request.getParameter("process");
		session=request.getSession();
		/*
		 * PrintWriter is a predefined class which is used to send data from servlet to front end technology
		 * such as ajax.
		 * We can also print any message on page with the help of printwriter
		 */
		PrintWriter pw=response.getWriter();
		
		if(process!=null && process.equals("updateCartQuantity")) {
			cartid=Integer.parseInt(request.getParameter("cartid"));
			quantity=Integer.parseInt(request.getParameter("quantity"));
			
			flag=cimpl.updateCart(cartid, quantity);
			if(flag) {
				
				c=cimpl.searchCartById(cartid);
				totalPrice=c.getTotalPrice();
				pw.print(totalPrice);
			}
			
		}
		
	}

}
