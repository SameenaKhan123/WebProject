package Controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import Impl.FoodDaoImpl;

/**
 * Servlet implementation class ImageController
 */
@MultipartConfig
@WebServlet("/ImageController")
public class ImageController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImageController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletFileUpload sf=new ServletFileUpload(new DiskFileItemFactory());
		try {
			
			List<FileItem> flist=sf.parseRequest(request);
			String image="";
			
			
				
				FileItem f=flist.get(0);
				image=f.getName();
				
				File file=new File("/home/luser/Batches/Sujina/OnlineFoodProject/src/main/webapp/images",image);
				f.write(file);
				
				
			
			HttpSession session=request.getSession();
			Integer foodId=(Integer)session.getAttribute("fid");
			
			boolean flag=new FoodDaoImpl().updateImage(foodId, image);		
			
			if(flag) {
			request.setAttribute("msg", "Image added successfully!!!");
			RequestDispatcher rd=request.getRequestDispatcher("MyIndex.jsp");
			rd.forward(request, response);
			
			}
			else {
				request.setAttribute("errorMsg", "Error while adding image!!!");
				RequestDispatcher rd=request.getRequestDispatcher("MyIndex.jsp");
				rd.forward(request, response);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
