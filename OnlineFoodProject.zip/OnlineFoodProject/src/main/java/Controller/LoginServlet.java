package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Impl.CustomerDaoImpl;
import Impl.LoginDaoImpl;
import POJO.Customer;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    LoginDaoImpl limpl=new LoginDaoImpl();
	Boolean flag;
	HttpSession session=null;
	String login, msg, errorMsg;
	RequestDispatcher rd=null;
	
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		session=request.getSession();
		
		
		session.invalidate();
		
		request.setAttribute("errorMsg", "You have logged out successfully!!!");
		rd=request.getRequestDispatcher("MyIndex.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		session=request.getSession();
		
		flag=limpl.userLogin(username, password);
		
		if(flag) {
			
			login="customer";
			Customer c=new CustomerDaoImpl().searchByEmailId(username);
			
			msg="Welcome to our website "+c.getCustName();
			
			session.setAttribute("login", login);
			request.setAttribute("msg", msg);
			session.setAttribute("username", username);
			
			rd=request.getRequestDispatcher("MyIndex.jsp");
			rd.forward(request, response);
		}
		
		else {
			
			flag=limpl.adminLogin(username, password);
			
			if(flag) {
				
				login="admin";
				msg="Welcome to our website. You have logged in as admin";
				
				session.setAttribute("login", login);
				request.setAttribute("msg", msg);
				session.setAttribute("username", username);
				
				rd=request.getRequestDispatcher("MyIndex.jsp");
				rd.forward(request, response);
				
			}
			else {
				login=null;
				errorMsg="Could not login. Please check the username and password given!!!";
				
				request.setAttribute("errorMsg", errorMsg);
				session.setAttribute("login", login);
				
				rd=request.getRequestDispatcher("Login.jsp");
				rd.forward(request, response);
				
			}
		}
	}

}
