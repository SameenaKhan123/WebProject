package Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.*;

import org.apache.commons.fileupload.*;
import org.apache.commons.fileupload.disk.*;
import org.apache.commons.fileupload.servlet.*;
import org.apache.commons.io.output.*;
import java.io.*;
import java.util.*;

import Impl.FoodDaoImpl;
import POJO.Food;

/**
 * Servlet implementation class FoodServlet
 */

@MultipartConfig
@WebServlet("/FoodServlet")
public class FoodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private int foodId;
	private String foodName;
	private String foodType;
	private String foodCategory;
	private String foodDesc;
	private Double foodPrice;
	private String image;
	Boolean flag;
	String login, msg, errorMsg;
	
	Food f=null;
	FoodDaoImpl fimpl=new FoodDaoImpl();
	List<Food> flist=null;
	RequestDispatcher rd=null;
	HttpSession session=null;
	
    public FoodServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String process=request.getParameter("process");
		session=request.getSession();
		
		if(process!=null && process.equals("allFood")) {
			
			
			flist=fimpl.getAllFood();
			session.setAttribute("flist", flist);
			
			response.sendRedirect("FoodList.jsp");
			
		}
		
		else if(process!=null && process.equals("updateFood")) {
			
			foodId=Integer.parseInt(request.getParameter("foodId"));
			
			f=fimpl.searchFood(foodId);
			session.setAttribute("foodObj", f);
			
			response.sendRedirect("UpdateFood.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String process=request.getParameter("process");
		
		if(process!=null && process.equals("addFood")) {
			
			foodName=request.getParameter("foodName");
			foodType=request.getParameter("foodType");
			foodCategory=request.getParameter("foodCategory");
			foodDesc=request.getParameter("foodDesc");
			foodPrice=Double.parseDouble(request.getParameter("foodPrice"));
			
					
			f=new Food();
			f.setFoodCategory(foodCategory);
			f.setFoodDesc(foodDesc);
			f.setFoodName(foodName);
			f.setFoodPrice(foodPrice);
			f.setFoodType(foodType);
			
			flag=fimpl.addFood(f);
			
			if(flag) {
				
				msg="Food item added to database succeffully!!!";
				request.setAttribute("msg", msg);
				
				rd=request.getRequestDispatcher("MyIndex.jsp");
				rd.forward(request, response);
				
			}
			else {
				
				errorMsg="Error while adding food item. Please try again!!!";
				request.setAttribute("errorMsg", errorMsg);
				
				rd=request.getRequestDispatcher("AddFood.jsp");
				rd.forward(request, response);
			}
			      	
			   }
		
		else if(process!=null && process.equals("editFood")) {
			
			foodName=request.getParameter("foodName");
			foodType=request.getParameter("foodType");
			foodCategory=request.getParameter("foodCategory");
			foodDesc=request.getParameter("foodDesc");
			foodPrice=Double.parseDouble(request.getParameter("foodPrice"));
			foodId=Integer.parseInt(request.getParameter("foodId"));
			
			f=new Food(foodId, foodName, foodType, foodCategory, foodDesc, foodPrice, image);
			flag=fimpl.updateFood(f);
			
			if(flag) {
				
				msg="Food item updated to database succeffully!!!";
				request.setAttribute("msg", msg);
				
				flist=fimpl.getAllFood();
				session.setAttribute("flist", flist);
				
				rd=request.getRequestDispatcher("FoodList.jsp");
				rd.forward(request, response);
				
			}
			else {
				
				errorMsg="Error while updating food details. Please try again!!!";
				request.setAttribute("errorMsg", errorMsg);
				
				rd=request.getRequestDispatcher("MyIndex.jsp");
				rd.forward(request, response);
			}
			
		}
}
	}

	
