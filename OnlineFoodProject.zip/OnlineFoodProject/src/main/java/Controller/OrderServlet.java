package Controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Impl.OrderDaoImpl;
import POJO.OrderFood;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private int orderId;
	private LocalDateTime orderDate;
	private double totalBill;
	private String emailId;
	private String orderStatus;
	Boolean flag;
	
	RequestDispatcher rd;
	HttpSession session;
	
	OrderFood o;
	List<OrderFood> olist;
	OrderDaoImpl oimpl=new OrderDaoImpl();
	
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String process=request.getParameter("process");
		session=request.getSession();
		
		if(process!=null && process.equals("myOrders")) {
			emailId=(String)session.getAttribute("username");
			
			olist=oimpl.showMyOrderHistory(emailId);
			
			if(olist==null || olist.isEmpty()) {
				
				request.setAttribute("errorMsg", "You have not ordered anything till now!!!");
				
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
			}
			else {
				
				request.setAttribute("msg", "Your orders....");
				
				session.setAttribute("olist", olist);
				rd=request.getRequestDispatcher("OrderList.jsp");
				rd.forward(request, response);
			}
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String process=request.getParameter("process");
		session=request.getSession();
		
		if(process!=null&& process.equals("placeOrder")) {
			
			emailId=(String) session.getAttribute("username");
			orderStatus="Order confirmed";
			
			o=new OrderFood();
			o.setEmailId(emailId);
			o.setOrderStatus(orderStatus);
			
			flag=oimpl.placeOrder(o);
			
			if(flag) {
				
				request.setAttribute("msg", "Your order has been placed successfully!!");
				
				rd=request.getRequestDispatcher("MyIndex.jsp");
				rd.forward(request, response);
			}
			else {
				
				request.setAttribute("errorMsg", "Error while placing order");
				
				rd=request.getRequestDispatcher("MyIndex.jsp");
				rd.forward(request, response);
			}
		}
	}

}
