package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Impl.CustomerDaoImpl;
import POJO.Customer;

/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private String custName;
	private String emailId;
	private String custPassword;
	private String custAddress;
	private String contactNo;
	private String custLocation;
	
	HttpSession session;
	RequestDispatcher rd;
	Customer c;
	CustomerDaoImpl cimpl=new CustomerDaoImpl();
	Boolean flag;
	
    public CustomerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String process=request.getParameter("process");
		session=request.getSession();
		
		if(process!=null && process.equals("updateProfile")) {
			
			emailId=(String)session.getAttribute("username");
			c=cimpl.searchByEmailId(emailId);
			
			session.setAttribute("custObj", c);
			response.sendRedirect("UpdateCustomer.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String process=request.getParameter("process");
		session=request.getSession();
		
		if(process!=null && process.equals("updateCustomer")) {
			
			custName=request.getParameter("custName");
			emailId=request.getParameter("emailId");
			custPassword=request.getParameter("custPassword");
			custAddress=request.getParameter("custAddress");
			contactNo=request.getParameter("contactNo");
			custLocation=request.getParameter("custLocation");
			
			c=new Customer(custName, emailId, custPassword, custAddress, contactNo, custLocation);
			
			flag=cimpl.updateCustomer(c);
			if(flag) {
				
				request.setAttribute("msg", "Your profile has been updated successfully!!!");
				
				session.invalidate();
				
				rd=request.getRequestDispatcher("Login.jsp");
				rd.forward(request, response);
			}
			
			else {
				
				request.setAttribute("errorMsg", "Error while updating your profile!! Please try again..");
				
				rd=request.getRequestDispatcher("UpdateCustomer.jsp");
				rd.forward(request, response);
			}
			
		}
	}

}
