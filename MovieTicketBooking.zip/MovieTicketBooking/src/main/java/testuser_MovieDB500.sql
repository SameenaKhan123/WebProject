Create database testuser_MovieDB500

CREATE TABLE `Movie_500` (
 `movieId` int(10) NOT NULL AUTO_INCREMENT,
 `movieName` varchar(100) DEFAULT NULL,
 `director` varchar(50) DEFAULT NULL,
 `producer` varchar(50) DEFAULT NULL,
 `cast` varchar(200) DEFAULT NULL,
 `releaseDate` date DEFAULT NULL,
 `lang` varchar(50) DEFAULT NULL,
 PRIMARY KEY (`movieId`)
);

create TABLE Customer_500(cId int PRIMARY KEY AUTO_INCREMENT, cname varchar(100), 
email varchar(200) UNIQUE KEY, password varchar(100) UNIQUE key, 
contactNo bigint UNIQUE KEY, age int, 	gender varchar(10));

CREATE TABLE `Show_500` (
 `showId` int(11) NOT NULL AUTO_INCREMENT,
 `movieId` int(10) DEFAULT NULL,
 `theatre_Location` varchar(200) DEFAULT NULL,
 `screenName` varchar(200) DEFAULT NULL,
 `showDate` date DEFAULT NULL,
 `startTime` varchar(20) DEFAULT NULL,
 `endTime` varchar(20) DEFAULT NULL,
 `ticketPrice` double(15,2) DEFAULT NULL,
 PRIMARY KEY (`showId`),
 KEY `movieId` (`movieId`),
 CONSTRAINT `Show_500_ibfk_1` FOREIGN KEY (`movieId`) REFERENCES `Movie_500` (`movieId`)
);


CREATE TABLE `Booking_500` (
 `bookId` int(11) NOT NULL AUTO_INCREMENT,
 `showId` int(11) DEFAULT NULL,
 `bookingDate` datetime DEFAULT NULL,
 `email` varchar(100) DEFAULT NULL,
 `seats` varchar(50) DEFAULT NULL,
 `totalBill` double(15,2) DEFAULT NULL,
 PRIMARY KEY (`bookId`),
 KEY `showId` (`showId`),
 CONSTRAINT `Booking_500_ibfk_1` FOREIGN KEY (`showId`) REFERENCES `Show_500` (`showId`)
);

CREATE TABLE `admin_500` (
 `adminId` int(11) NOT NULL AUTO_INCREMENT,
 `adminEmail` varchar(200) DEFAULT NULL,
 `adminPassword` varchar(200) DEFAULT NULL,
 PRIMARY KEY (`adminId`)
);
