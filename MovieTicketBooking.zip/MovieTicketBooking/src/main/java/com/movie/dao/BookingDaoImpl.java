package com.movie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.movie.pojo.Booking;
import com.movie.pojo.Show;
import com.movie.util.DBConnection;

public class BookingDaoImpl implements BookingDao {
	Connection con=null;
	String sql=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	Booking b=null;
	List<Booking> blist=null;
	
	@Override
	public Booking bookMyShow(Booking b) {
		con=DBConnection.makeConnection();
		sql="insert into Booking_500(showId, bookingDate, email, seats, totalBill, status) "
				+ "values(?, ?, ?, ?, ?, ?)";
		try {
			/*
			 * Statement.RETURN_GENERATED_KEYS is a final variable in Statement object
			 * which stores the primary key generated in the table for the above given
			 * insert query.
			 * 
			 */
			ps=con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setInt(1, b.getShowId());
			
			LocalDateTime today=LocalDateTime.now();
			DateTimeFormatter pattern=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			
			String date=today.format(pattern);
			
			ps.setTimestamp(2, Timestamp.valueOf(date));
			
			ps.setString(3, b.getEmail());
			ps.setString(4, b.getSeats());
			ps.setDouble(5, b.getTotalBill());
			ps.setString(6, "Confirmed");
			
			int i=ps.executeUpdate();
			if(i>0)
				{
				/*
				 * If the insert query is successfully executed then we need to fetch
				 * the primary key from the RETURN_GENERATED_KEYS variable.
				 * This is done by calling getGeneratedKeys() method.
				 */
				rs=ps.getGeneratedKeys();
				if(rs.next()) {
					
					int bookId=rs.getInt(1);//storing the primary key in variable bookId
					b=searchBookingById(bookId);//fetching Booking object for this id.
					return b;
				}
				
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean cancelMyBooking(Integer bookId) {
		con=DBConnection.makeConnection();
		sql="update Booking_500 set status='Cancelled' where bookId=?";
		
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, bookId);
			
			int i=ps.executeUpdate();
			if(i>0) 
				return true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public List<Booking> displayMyBookingHistory(String email) {
		con=DBConnection.makeConnection();
		sql="select * from Booking_500 where email=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, email);
			
			
			rs=ps.executeQuery();
			blist=new ArrayList<>();
			
			while(rs.next()) {
				b=new Booking();
				b.setBookId(rs.getInt(1));
				
				b.setBookingDate(rs.getTimestamp(3).toLocalDateTime());
				b.setEmail(rs.getString(4));
				
				Show s=new ShowDaoImpl().searchShowById(rs.getInt(2));
				b.setS(s);
				
				LocalDate showDate= s.getShowDate();
				LocalDate today=LocalDate.now();
				
				Period p=Period.between(today, showDate);
				int days=p.getDays();
				String status=rs.getString(7);
				
				if(days<0 && !status.equals("Cancelled")) {
					
					b.setStatus("Screening done");
				}
				else {
					b.setStatus(status);
				}
				b.setShowId(rs.getInt(2));
				b.setTotalBill(rs.getDouble(6));
				b.setSeats(rs.getString(5));
				
				
				blist.add(b);
			}
			
			return blist;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Booking searchBookingById(Integer bookId) {
		con=DBConnection.makeConnection();
		sql="select * from Booking_500 where bookId=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, bookId);
			
			rs=ps.executeQuery();
			if(rs.next()) {
				b=new Booking();
				b.setBookId(rs.getInt(1));
				
				b.setBookingDate(rs.getTimestamp(3).toLocalDateTime());
				b.setEmail(rs.getString(4));
				
				Show s=new ShowDaoImpl().searchShowById(rs.getInt(2));
				b.setS(s);
				
				b.setShowId(rs.getInt(2));
				b.setTotalBill(rs.getDouble(6));
				b.setSeats(rs.getString(5));
				b.setStatus(rs.getString(7));
				
				return b;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Booking> showAllBookings() {
		con=DBConnection.makeConnection();
		sql="select * from Booking_500";
		try {
			ps=con.prepareStatement(sql);
			
			
			rs=ps.executeQuery();
			blist=new ArrayList<>();
			
			while(rs.next()) {
				b=new Booking();
				b.setBookId(rs.getInt(1));
				
				b.setBookingDate(rs.getTimestamp(3).toLocalDateTime());
				b.setEmail(rs.getString(4));
				
				Show s=new ShowDaoImpl().searchShowById(rs.getInt(2));
				b.setS(s);
				
				LocalDate showDate= s.getShowDate();
				LocalDate today=LocalDate.now();
				
				Period p=Period.between(today, showDate);
				int days=p.getDays();
				String status=rs.getString(7);
				
				if(days<0 && !status.equals("Cancelled")) {
					
					b.setStatus("Screening done");
				}
				else {
					b.setStatus(status);
				}
				b.setShowId(rs.getInt(2));
				b.setTotalBill(rs.getDouble(6));
				b.setSeats(rs.getString(5));
				
				
				blist.add(b);
			}
			
			return blist;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
	
	public List<String> getReservedSeats(Integer showId){
		List<String> reservedSeats=new ArrayList<>();
		con=DBConnection.makeConnection();
		sql="select seats from Booking_500 where showId=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, showId);
			
			rs=ps.executeQuery();
			while(rs.next()) {
				
				String seats=rs.getString(1);//A1,A2
				String []arr=seats.split(",");//["A1", "A2" ]
				for(String x:arr)
					reservedSeats.add(x);
			}
			
			return reservedSeats;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void changeStatus(Integer bookId, LocalDate showDate) {
		
		
		LocalDate today=LocalDate.now();
		
		Period p=Period.between(today, showDate);
		int days=p.getDays();
		if(days<0) {
			con=DBConnection.makeConnection();
			sql="update Booking_500 set status='Screening done' where bookId=? && status!='Cancelled'";
			try {
				ps=con.prepareStatement(sql);
				ps.setInt(1, bookId);
				
				ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
