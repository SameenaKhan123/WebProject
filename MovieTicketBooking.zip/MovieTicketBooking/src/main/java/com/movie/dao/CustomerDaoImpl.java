package com.movie.dao;

import java.util.ArrayList;
import java.util.List;

import com.movie.pojo.Customer;
import com.movie.util.DBConnection;
import java.sql.*;

public class CustomerDaoImpl implements CustomerDao{
	Connection con=null;
	PreparedStatement ps=null;
	String sql=null;
	ResultSet rs=null;
	Customer c=null;
	List<Customer> clist=null;
	private Integer cId;
	private String cname;
	private String email;
	private String password;
	private Long contactNo;
	private Integer age;
	private String gender;
	
	@Override
	public boolean addCustomer(Customer c) {
		con=DBConnection.makeConnection();
		sql="insert into Customer_500(cname, email, password, contactNo, age, gender) values (?, ?, ?, ?, ?, ?)";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, c.getCname());
			ps.setString(2, c.getEmail());
			ps.setString(3, c.getPassword());
			ps.setLong(4, c.getContactNo());
			ps.setInt(5, c.getAge());
			ps.setString(6, c.getGender());
			
			
			int i=ps.executeUpdate();
			if(i>0)
				return true;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

		return false;
	}

	@Override
	public boolean updateCustomer(Customer c) {
		
		con=DBConnection.makeConnection();
		sql="update Customer_500 set cname=?, email=?, password=?, contactNo=?, age=?, gender=? where cId=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, c.getCname());
			ps.setString(2, c.getEmail());
			ps.setString(3, c.getPassword());
			ps.setLong(4, c.getContactNo());
			ps.setInt(5, c.getAge());
			ps.setString(6, c.getGender());
			ps.setInt(7, c.getcId());
			
			int i=ps.executeUpdate();
			if(i>0)
				return true;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return false;
	}

	@Override
	public boolean deleteCustomer(Integer cId) {
		con=DBConnection.makeConnection();
		sql="delete from Customer_500 where cId=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, cId);
			
			int i=ps.executeUpdate();
			if(i>0)
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Customer searchCustomerById(Integer cId) {
		con=DBConnection.makeConnection();
		sql="select * from Customer_500 where cId=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, cId);
			
			
			
			rs=ps.executeQuery();
			
			if(rs.next()) {
				
				c=new Customer();
				c.setAge(rs.getInt("age"));
				c.setcId(rs.getInt("cId"));
				c.setCname(rs.getString("cname"));
				c.setContactNo(rs.getLong("contactNo"));
				c.setEmail(rs.getString("email"));
				c.setGender(rs.getString("gender"));
				c.setPassword(rs.getString("password"));
				
				return c;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}


		return null;
	}

	@Override
	public List<Customer> fetchAllCustomer() {
		con=DBConnection.makeConnection();
		sql="select * from Customer_500";
		try {
			ps=con.prepareStatement(sql);
			
			
			clist=new ArrayList<>();
			
			rs=ps.executeQuery();
			while(rs.next()) {
				
				c=new Customer();
				c.setAge(rs.getInt("age"));
				c.setcId(rs.getInt("cId"));
				c.setCname(rs.getString("cname"));
				c.setContactNo(rs.getLong("contactNo"));
				c.setEmail(rs.getString("email"));
				c.setGender(rs.getString("gender"));
				c.setPassword(rs.getString("password"));
				
				clist.add(c);
			}
			return clist;
		} catch (Exception e) {
			e.printStackTrace();
		}


		return null;
	}

	@Override
	public List<Customer> searchCustomerByName(String cname) {
		con=DBConnection.makeConnection();
		sql="select * from Customer_500 where cname like ?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, "%"+cname+"%");
			
			clist=new ArrayList<>();
			
			rs=ps.executeQuery();
			while(rs.next()) {
				
				c=new Customer();
				c.setAge(rs.getInt("age"));
				c.setcId(rs.getInt("cId"));
				c.setCname(rs.getString("cname"));
				c.setContactNo(rs.getLong("contactNo"));
				c.setEmail(rs.getString("email"));
				c.setGender(rs.getString("gender"));
				c.setPassword(rs.getString("password"));
				
				clist.add(c);
			}
			return clist;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public Customer searchCustomerByEmail(String email) {
		con=DBConnection.makeConnection();
		sql="select * from Customer_500 where email=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, email);
			
			rs=ps.executeQuery();
			if(rs.next()) {
				
				c=new Customer();
				c.setAge(rs.getInt("age"));
				c.setcId(rs.getInt("cId"));
				c.setCname(rs.getString("cname"));
				c.setContactNo(rs.getLong("contactNo"));
				c.setEmail(rs.getString("email"));
				c.setGender(rs.getString("gender"));
				c.setPassword(rs.getString("password"));
				
				return c;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean uniquePassword(String password) {
		con=DBConnection.makeConnection();
		sql="select password from Customer_500 where password=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, password);
			
			rs=ps.executeQuery();
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean uniqueContact(Long contactNo) {
		con=DBConnection.makeConnection();
		sql="select contactNo from Customer_500 where contactNo=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setLong(1, contactNo);
			
			rs=ps.executeQuery();
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean uniqueEmail(String email) {
		con=DBConnection.makeConnection();
		sql="select email from Customer_500 where email=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, email);
			
			rs=ps.executeQuery();
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
}
