package com.movie.pojo;

import java.time.LocalDateTime;

public class Booking {
	
	private Integer bookId;
	private Integer showId; 
	private Show s;
	private LocalDateTime bookingDate;
	private String email;
	private String seats;
	private Double totalBill;
	private String status;
	
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Booking(Integer bookId, Integer showId, Show s, LocalDateTime bookingDate, String email, String seats,
			Double totalBill) {
		super();
		this.bookId = bookId;
		this.showId = showId;
		this.s = s;
		this.bookingDate = bookingDate;
		this.email = email;
		this.seats = seats;
		this.totalBill = totalBill;
	}
	
	
	public Booking(Integer showId, Show s, LocalDateTime bookingDate, String email, String seats, Double totalBill) {
		super();
		this.showId = showId;
		this.s = s;
		this.bookingDate = bookingDate;
		this.email = email;
		this.seats = seats;
		this.totalBill = totalBill;
	}
	@Override
	public String toString() {
		return "Booking [bookId=" + bookId + ", showId=" + showId + ", s=" + s + ", bookingDate=" + bookingDate
				+ ", email=" + email + ", seats=" + seats + ", totalBill=" + totalBill + "]";
	}
	public Integer getBookId() {
		return bookId;
	}
	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}
	public Integer getShowId() {
		return showId;
	}
	public void setShowId(Integer showId) {
		this.showId = showId;
	}
	public Show getS() {
		return s;
	}
	public void setS(Show s) {
		this.s = s;
	}
	public LocalDateTime getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(LocalDateTime bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSeats() {
		return seats;
	}
	public void setSeats(String seats) {
		this.seats = seats;
	}
	public Double getTotalBill() {
		return totalBill;
	}
	public void setTotalBill(Double totalBill) {
		this.totalBill = totalBill;
	}
	
	
}
