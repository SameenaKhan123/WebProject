package com.movie.test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.movie.dao.LoginDaoImpl;
import com.movie.dao.ShowDaoImpl;
import com.movie.pojo.Movie;
import com.movie.pojo.Show;

public class ShowTest {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		LoginDaoImpl limpl=new LoginDaoImpl();
		ShowDaoImpl simpl=new ShowDaoImpl();
		Show s=null;
		List<Show> slist=null;
		boolean flag;
		
		Integer showId;
		Integer movieId;
		Movie m;
		String theatre_Location;
		String screenName;
		LocalDate showDate;
		LocalTime startTime;
		LocalTime endTime;
		Double ticketPrice;
		int day, month, year, hours, mins;
		int option;
		
		System.out.print("Enter user name: Your email id: ");
		String username=sc.nextLine();
		
		System.out.print("Enter password: ");
		String password=sc.nextLine();
		
		
		flag=limpl.checkAdmin(username, password);
		
		if(flag) {
			System.out.println("You have logged in as Admin");
			
			slist=simpl.fetchAllShow();
			if(slist!=null && slist.isEmpty()!=true) {
				
				for(Show s1:slist) {
					System.out.println(s1);
					System.out.println("__________________________________________");
				}
				
				
				while(true) {
					
					System.out.println("Enter 1----> Add new show");
					System.out.println("Enter 2----> Update show");
					System.out.println("Enter 3----> Delete a show");
					System.out.println("Enter 4----> Display all shows");
					System.out.println("Enter 5----> Exit");
					option=sc.nextInt();
					sc.nextLine();
					
					switch(option) {
					case 1:
						HashMap<Integer, String>hm=simpl.searchMovieId();
						Set<Map.Entry<Integer, String>> pairs=hm.entrySet();
						
						for(Map.Entry<Integer, String> p:pairs) {
							System.out.println("Movie id: "+p.getKey()+" Movie name: "+p.getValue());
						}
						
						System.out.print("Enter movie id: ");
						movieId=sc.nextInt();
						sc.nextLine();
						
						System.out.print("Enter theatre name and location: ");
						theatre_Location=sc.nextLine();
						
						System.out.print("Enter screen name: ");
						screenName=sc.nextLine();
						
						System.out.print("Enter day of show. Number between 1 to 31 only:	");
						day=sc.nextInt();
						sc.nextLine();
						
						
						System.out.print("Enter month of show. Number between 1 to 12 only:	");
						month=sc.nextInt();
						sc.nextLine();
						
						System.out.print("Enter year of show :	");
						year=sc.nextInt();
						sc.nextLine();
						
						showDate=LocalDate.of(year, month, day);
						
						System.out.print("Enter hour at which movie will start: ");
						hours=sc.nextInt();
						sc.nextLine();
						
						System.out.println("Enter minutes of start time");
						mins=sc.nextInt();
						sc.nextLine();
						
						startTime=LocalTime.of(hours, mins);
						
						System.out.print("Enter hour at which movie will end: ");
						hours=sc.nextInt();
						sc.nextLine();
						
						System.out.println("Enter minutes of end time");
						mins=sc.nextInt();
						sc.nextLine();
						
						endTime=LocalTime.of(hours, mins);
						
						System.out.print("Enter ticket price: ");
						ticketPrice=sc.nextDouble();
						sc.nextLine();
						
						s=new Show();
						s.setEndTime(endTime);
						s.setMovieId(movieId);
						s.setScreenName(screenName);
						s.setShowDate(showDate);
						s.setStartTime(startTime);
						s.setTheatre_Location(theatre_Location);
						s.setTicketPrice(ticketPrice);
						
						flag=simpl.addShow(s);
						
						if(flag)
							System.out.println("Show added successfully");
						else
							System.out.println("Error while adding show");
						
						break;
					case 2:
						System.out.print("Enter show Id: ");
						showId=sc.nextInt();
						sc.nextLine();
						
						s=simpl.searchShowById(showId);
						if(s!=null) {
						
							System.out.println("********Show Details********");
							System.out.println("Theatre name and location: "+s.getTheatre_Location());
							System.out.println("Screen name: "+s.getScreenName());
							System.out.println("Movie: "+s.getM().getMovieName());
							System.out.println("Show date: "+s.getShowDate());
							System.out.println("Timing From: "+s.getStartTime()+" to: "+s.getEndTime());
							System.out.println("Ticket price: "+s.getTicketPrice());
							
							System.out.println("Do you want to update this?Answer in yes or no.");
							String choice=sc.nextLine();
							
							if(choice.equalsIgnoreCase("yes")) {
								
								System.out.print("Enter theatre name and location: ");
								theatre_Location=sc.nextLine();
								
								System.out.print("Enter screen name: ");
								screenName=sc.nextLine();
								
								System.out.print("Enter day of show. Number between 1 to 31 only:	");
								day=sc.nextInt();
								sc.nextLine();
								
								
								System.out.print("Enter month of show. Number between 1 to 12 only:	");
								month=sc.nextInt();
								sc.nextLine();
								
								System.out.print("Enter year of show :	");
								year=sc.nextInt();
								sc.nextLine();
								
								showDate=LocalDate.of(year, month, day);
								
								System.out.print("Enter hour at which movie will start: ");
								hours=sc.nextInt();
								sc.nextLine();
								
								System.out.println("Enter minutes of start time");
								mins=sc.nextInt();
								sc.nextLine();
								
								startTime=LocalTime.of(hours, mins);
								
								System.out.print("Enter hour at which movie will end: ");
								hours=sc.nextInt();
								sc.nextLine();
								
								System.out.println("Enter minutes of end time");
								mins=sc.nextInt();
								sc.nextLine();
								
								endTime=LocalTime.of(hours, mins);
								
								System.out.print("Enter ticket price: ");
								ticketPrice=sc.nextDouble();
								sc.nextLine();
								
								
								s.setShowId(showId);
								s.setTheatre_Location(theatre_Location);
								s.setScreenName(screenName);
								s.setShowDate(showDate);
								s.setStartTime(startTime);
								s.setEndTime(endTime);
								s.setTicketPrice(ticketPrice);
								
								flag=simpl.updateShow(s);
								
								if(flag)
									System.out.println("Show updated successfully!!");
								else
									System.out.println("Error while updating show");
								
							}
							else if(choice.equalsIgnoreCase("no"))
								System.out.println("Thank you continue browsing");
							else
								System.out.println("Please give answer in yes or no only");
						}
						else
							System.out.println("No such show details found with this id.");
						
						break;
						
					case 3:
						System.out.print("Enter show Id: ");
						showId=sc.nextInt();
						sc.nextLine();
						
						s=simpl.searchShowById(showId);
						if(s!=null) {
						
							System.out.println("********Show Details********");
							System.out.println("Theatre name and location: "+s.getTheatre_Location());
							System.out.println("Screen name: "+s.getScreenName());
							System.out.println("Movie: "+s.getM().getMovieName());
							System.out.println("Show date: "+s.getShowDate());
							System.out.println("Timing From: "+s.getStartTime()+" to: "+s.getEndTime());
							System.out.println("Ticket price: "+s.getTicketPrice());
							
							System.out.println("Do you want to delete this?Answer in yes or no.");
							String choice=sc.nextLine();
							
							if(choice.equalsIgnoreCase("yes")) {
								
								flag=simpl.deleteShow(showId);
								
								if(flag)
									System.out.println("Show deleted successfully!!");
								else
									System.out.println("Error while deleting show details");
								
							}
							else if(choice.equalsIgnoreCase("no"))
								System.out.println("Thank you continue browsing");
							else
								System.out.println("Please give answer in yes or no only");
						}
						else
							System.out.println("No such show details found with this id.");
						
						
						break;
						
					case 4:
						slist=simpl.fetchAllShow();
						if(slist!=null && slist.isEmpty()!=true) {
							for(Show s1: slist) {
								
								System.out.println("\nTheatre name and location: "+s1.getTheatre_Location());
								System.out.println("Screen name: "+s1.getScreenName());
								System.out.println("Movie: "+s1.getM().getMovieName());
								System.out.println("Show date: "+s1.getShowDate());
								System.out.println("Timing From: "+s1.getStartTime()+" to: "+s1.getEndTime());
								System.out.println("Ticket price: "+s1.getTicketPrice());
								System.out.println("______________________________________________________");
								
							}
						}
						break;
						
					case 5:
						System.out.println("Thank you. Visit us soon");
						System.exit(0);
						
						break;
						
					default:System.out.println("Please give inputs according to options given");
					}
				}
			}
			else {
				
				System.out.println("There are no shows currently. Please add shows..");
				HashMap<Integer, String>hm=simpl.searchMovieId();
				Set<Map.Entry<Integer, String>> pairs=hm.entrySet();
				
				for(Map.Entry<Integer, String> p:pairs) {
					System.out.println("Movie id: "+p.getKey()+" Movie name: "+p.getValue());
				}
				
				System.out.print("Enter movie id: ");
				movieId=sc.nextInt();
				sc.nextLine();
				
				System.out.print("Enter theatre name and location: ");
				theatre_Location=sc.nextLine();
				
				System.out.print("Enter screen name: ");
				screenName=sc.nextLine();
				
				System.out.print("Enter day of show. Number between 1 to 31 only:	");
				day=sc.nextInt();
				sc.nextLine();
				
				
				System.out.print("Enter month of show. Number between 1 to 12 only:	");
				month=sc.nextInt();
				sc.nextLine();
				
				System.out.print("Enter year of show :	");
				year=sc.nextInt();
				sc.nextLine();
				
				showDate=LocalDate.of(year, month, day);
				
				System.out.print("Enter hour at which movie will start: ");
				hours=sc.nextInt();
				sc.nextLine();
				
				System.out.println("Enter minutes of start time");
				mins=sc.nextInt();
				sc.nextLine();
				
				startTime=LocalTime.of(hours, mins);
				
				System.out.print("Enter hour at which movie will end: ");
				hours=sc.nextInt();
				sc.nextLine();
				
				System.out.println("Enter minutes of end time");
				mins=sc.nextInt();
				sc.nextLine();
				
				endTime=LocalTime.of(hours, mins);
				
				System.out.print("Enter ticket price: ");
				ticketPrice=sc.nextDouble();
				sc.nextLine();
				
				s=new Show();
				s.setEndTime(endTime);
				s.setMovieId(movieId);
				s.setScreenName(screenName);
				s.setShowDate(showDate);
				s.setStartTime(startTime);
				s.setTheatre_Location(theatre_Location);
				s.setTicketPrice(ticketPrice);
				
				flag=simpl.addShow(s);
				
				if(flag)
					System.out.println("Show added successfully");
				else
					System.out.println("Error while adding show");
			}
		}
		else {
			
			flag=limpl.checkCustomer(username, password);
			if(flag) {
				System.out.println("You have logged in as Customer");
				while(true) {
					
					System.out.println("Enter 1----> Display all shows");
					System.out.println("Enter 2----> Search shows by theatre name or location");
					System.out.println("Enter 3----> Search by movie");
					System.out.println("Enter 4----> Search by timings");
					System.out.println("Enter 5----> Exit");
					
					option=sc.nextInt();
					sc.nextLine();
					
					switch(option) {
					
					case 1:
						slist=simpl.fetchAllShow();
						if(slist!=null && slist.isEmpty()!=true) {
							for(Show s1: slist) {
								
								System.out.println("\nTheatre name and location: "+s1.getTheatre_Location());
								System.out.println("Screen name: "+s1.getScreenName());
								System.out.println("Movie: "+s1.getM().getMovieName());
								System.out.println("Show date: "+s1.getShowDate());
								System.out.println("Timing From: "+s1.getStartTime()+" to: "+s1.getEndTime());
								System.out.println("Ticket price: "+s1.getTicketPrice());
								System.out.println("______________________________________________________");
								
							}
						}
						break;
						
					case 2: 
						System.out.println("Enter the theatre name or location");
						theatre_Location=sc.nextLine();
						
						slist=simpl.searchShowByTheatre(theatre_Location);
						if(slist!=null && slist.isEmpty()!=true) {
							for(Show s1: slist) {
								
								System.out.println("\nTheatre name and location: "+s1.getTheatre_Location());
								System.out.println("Screen name: "+s1.getScreenName());
								System.out.println("Movie: "+s1.getM().getMovieName());
								System.out.println("Show date: "+s1.getShowDate());
								System.out.println("Timing From: "+s1.getStartTime()+" to: "+s1.getEndTime());
								System.out.println("Ticket price: "+s1.getTicketPrice());
								System.out.println("______________________________________________________");
								
							}
						}
						else
							System.out.println("No shows for this particular search");
						break;
						
					case 3:
						System.out.print("Enter movie name:");
						String movieName=sc.nextLine();
						
						slist=simpl.searchShowByMovie(movieName);
						
						if(slist!=null && slist.isEmpty()!=true) {
							for(Show s1: slist) {
								
								System.out.println("\nTheatre name and location: "+s1.getTheatre_Location());
								System.out.println("Screen name: "+s1.getScreenName());
								System.out.println("Movie: "+s1.getM().getMovieName());
								System.out.println("Show date: "+s1.getShowDate());
								System.out.println("Timing From: "+s1.getStartTime()+" to: "+s1.getEndTime());
								System.out.println("Ticket price: "+s1.getTicketPrice());
								System.out.println("______________________________________________________");
								
							}
						}
						else
							System.out.println("No shows for this particular search");
						
						break;
						
					case 4:
						System.out.print("Enter the time: ");
						System.out.print("Enter hour at which movie will start: ");
						hours=sc.nextInt();
						sc.nextLine();
						
						System.out.println("Enter minutes of start time");
						mins=sc.nextInt();
						sc.nextLine();
						
						startTime=LocalTime.of(hours, mins);
						
						slist=simpl.searchShowByTime(startTime);
						if(slist!=null && slist.isEmpty()!=true) {
							for(Show s1: slist) {
								
								System.out.println("\nTheatre name and location: "+s1.getTheatre_Location());
								System.out.println("Screen name: "+s1.getScreenName());
								System.out.println("Movie: "+s1.getM().getMovieName());
								System.out.println("Show date: "+s1.getShowDate());
								System.out.println("Timing From: "+s1.getStartTime()+" to: "+s1.getEndTime());
								System.out.println("Ticket price: "+s1.getTicketPrice());
								System.out.println("______________________________________________________");
								
							}
						}
						else
							System.out.println("No shows for this particular search");
						
						break;
						
					case 5: 
						System.out.println("Thank you!!! Visit us soon!!!");
						System.exit(0);
						
						default:System.out.println("Please give inputs according to options given");
					}
				}
			}
			else
				System.err.println("Invalid credentials given. Please try again");
		}
		

	}

}
