package com.movie.test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.movie.dao.BookingDaoImpl;
import com.movie.dao.CustomerDaoImpl;
import com.movie.dao.LoginDaoImpl;
import com.movie.dao.ShowDaoImpl;
import com.movie.pojo.Booking;
import com.movie.pojo.Customer;
import com.movie.pojo.Movie;
import com.movie.pojo.Show;

public class BookingTest {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		LoginDaoImpl limpl=new LoginDaoImpl();
		boolean flag, exit=false;
		Booking b=null;
		BookingDaoImpl bimpl=new BookingDaoImpl();
		List<Booking> blist=null;
		List<Show> slist=null;
		ShowDaoImpl simpl=new ShowDaoImpl();
		
		int option;
		Integer bookId;
		Integer showId; 
		Show s;
		LocalDateTime bookingDate;
		String email;
		String seats="";
		Double totalBill;
		
		while(true) {
			
			
		System.out.print("Enter user name: Your email id: ");
		String username=sc.nextLine();
		
		System.out.print("Enter password: ");
		String password=sc.nextLine();
		
		
		flag=limpl.checkAdmin(username, password);
		if(flag) {
			
			System.out.println("You have logged in as Admin");
			
			do {
				
				System.out.println("Enter 1----> Search booking by id");
				System.out.println("Enter 2----> Show all bookings");
				System.out.println("Enter 3----> Exit");
				
				option=sc.nextInt();
				sc.nextLine();
				
				switch(option) {
				
				case 1:
					System.out.println("Enter booking id");
					bookId=sc.nextInt();
					sc.nextLine();
					
					b=bimpl.searchBookingById(bookId);
					if(b!=null) {
						
						System.out.println("*****Your search result*******");
						System.out.println(b);
					}
					else
						System.out.println("No data found with this id...");
					break;
					
				case 2:
					blist=bimpl.showAllBookings();
					if(blist!=null) {
						for(Booking b1: blist) {
							
							System.out.println("Show date: "+b1.getS().getShowDate());
							System.out.println("Timing: "+b1.getS().getStartTime()+" to: "
												+b1.getS().getEndTime());
							System.out.println("Email: "+b1.getEmail());
							System.out.println("Seats: "+b1.getSeats());
							System.out.println("Total bill: "+b1.getTotalBill());
							System.out.println("_____________________________________________");
							
						}
					}
					break;
				case 3:
					System.out.println("Thank you visit us soon!!!");
					exit=true;
					System.exit(0);
					break;
					
					default: System.err.println("In valid input. Please give numbers from options only");
				}
			}
			while(exit==false);
			
			
		}
		else {
			
			flag=limpl.checkCustomer(username, password);
			if(flag) {
				Customer c=new CustomerDaoImpl().searchCustomerByEmail(username);
				System.out.println("Welcome to our website "+c.getCname());
				
				do {
					System.out.println("Enter 1-----> Book my show");
					System.out.println("Enter 2-----> Cancel my booking");
					System.out.println("Enter 3-----> My booking history");
					System.out.println("Enter 4-----> Exit");
					
					option=sc.nextInt();
					sc.nextLine();
					
					switch(option) {
					
					case 1:
						slist=simpl.fetchAllShow();
						for(Show s1: slist) {
							System.out.println("Show Id: "+s1.getShowId());
							
							Movie m=s1.getM();
							
							System.out.println("Movie name: "+m.getMovieName());
							System.out.println("Cast: "+m.getCast());
							System.out.println("Theatre, location: "+s1.getTheatre_Location());
							System.out.println("Date: "+s1.getShowDate());
							System.out.println("Timing: "+s1.getStartTime()+" : "+s1.getEndTime());
							System.out.println("Price: "+s1.getTicketPrice());
							System.out.println("_________________________________________");
							
						}
						System.out.print("Enter show id: ");
						showId=sc.nextInt();
						sc.nextLine();
						
						
								
						email=username;
						
						System.out.print("Enter the no. of seats to be booked: ");
						int noOfSeats=sc.nextInt();
						sc.nextLine();
						
						for(int i=1; i<=noOfSeats; i++) {
							System.out.print("Enter seat name:");
							
							if(i==noOfSeats)
								seats+=sc.next();
							else
								seats+=sc.next()+", ";
							
							
							
						}
						
						sc.nextLine();
						s=simpl.searchShowById(showId);
						double ticketPrice=s.getTicketPrice();
						
						totalBill=noOfSeats*ticketPrice;
						
						b=new Booking();
						//b.setBookingDate(LocalDateTime.parse(date));
						b.setEmail(email);
						b.setSeats(seats);
						b.setShowId(showId);
						b.setTotalBill(totalBill);
						
						Booking b1=bimpl.bookMyShow(b);
						
						if(b1!=null) {
							
							System.out.println("******Your show has been booked********");
							System.out.println("Enjoy!!!!!");
							System.out.println("Movie name: "+b1.getS().getM().getMovieName());
							System.out.println("Date: "+b1.getS().getShowDate());
							System.out.println("Theatre name: "+b1.getS().getTheatre_Location());
							System.out.println("Screen: "+b1.getS().getScreenName());
							System.out.println("Timings: "+b1.getS().getStartTime()
									+" to "+b1.getS().getEndTime());
							System.out.println("Seats: "+b1.getSeats());
							System.out.println("Status: Confirmed");
							
						}
						else
							System.out.println("Error while booking this show. Please try again");
						
						break;
						
					case 2:
						System.out.print("Enter booking id:");
						bookId=sc.nextInt();
						sc.nextLine();
						
						flag=bimpl.cancelMyBooking(bookId);
						
						if(flag)
							System.out.println("Your booking has been cancelled successfully");
						else
							System.out.println("Error while cancelling this booking!!!");
						break;
					case 3:
						email=username;
						blist=bimpl.displayMyBookingHistory(email);
						
						if(blist!=null && !blist.isEmpty()) {
							
							for(Booking b2: blist) {
								
								System.out.println("Movie name: "+b2.getS().getM().getMovieName());
								System.out.println("Date: "+b2.getS().getShowDate());
								System.out.println("Theatre name: "+b2.getS().getTheatre_Location());
								System.out.println("Screen: "+b2.getS().getScreenName());
								System.out.println("Timings: "+b2.getS().getStartTime()
										+" to "+b2.getS().getEndTime());
								System.out.println("Seats: "+b2.getSeats());
								System.out.println("Status: "+b2.getStatus());
								System.out.println("__________________\n");
							}
						}
						break;
						
					case 4:
						System.out.println("Thank you!!!");
						break;
						default: System.out.println("Please give input according to option");
					}
					
				}
				while(exit==false);
				
			}
			else {
				
				System.out.println("Given credentials are wrong. Please try again");
			}
		}
		
		}
	}

}
