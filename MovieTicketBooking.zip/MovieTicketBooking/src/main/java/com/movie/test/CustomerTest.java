package com.movie.test;

import java.util.List;
import java.util.Scanner;

import com.movie.dao.CustomerDaoImpl;
import com.movie.pojo.Customer;

public class CustomerTest {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Customer c=null;
		CustomerDaoImpl cimpl=new CustomerDaoImpl();
		List<Customer> clist=null;
		
		Boolean flag;
		Integer cId;
		String cname;
		String email;
		String password;
		Long contactNo;
		Integer age;
		String gender;
		
		while(true) {
			
			System.out.println("Enter the given options....");
			System.out.println("Enter 1------>Sign up");
			
			int option=sc.nextInt();
			sc.nextLine();
			
			switch(option) {
			
			case 1:
				System.out.println("Enter name: ");
				cname=sc.nextLine();
				
				System.out.println("Enter email: ");
				email=sc.nextLine();
				flag=cimpl.uniqueEmail(email);
				while(flag)
				{
					System.err.println("This email is already being used by other customer.");
					System.out.println("Please give another input...");
					email=sc.nextLine();
					flag=cimpl.uniqueEmail(email);
				}
				
				System.out.println("Enter password");
				password=sc.nextLine();
				flag=cimpl.uniquePassword(password);
				while(flag)
				{
					System.err.println("This password is already being used by other customer.");
					System.out.println("Please give another input...");
					password=sc.nextLine();
					flag=cimpl.uniquePassword(password);
				}
				
				
				System.out.println("Enter contact number");
				contactNo=sc.nextLong();
				sc.nextLine();
				
				flag=cimpl.uniqueContact(contactNo);
				while(flag)
				{
					System.err.println("This number is already being used by other customer.");
					System.out.println("Please give another input...");
					contactNo=sc.nextLong();
					sc.nextLine();
					flag=cimpl.uniqueContact(contactNo);
				}
				
				System.out.println("Enter age");
				age=sc.nextInt();
				sc.nextLine();
				
				System.out.println("Enter gender:");
				gender=sc.nextLine();
				
				c=new Customer();
				c.setAge(age);
				c.setCname(cname);
				c.setContactNo(contactNo);
				c.setEmail(email);
				c.setGender(gender);
				c.setPassword(password);
				
				flag=cimpl.addCustomer(c);
				
				if(flag)
					System.out.println("Your profile registered successfully");
				else
					System.out.println("Error...");
				
				break;
			}
		}

	}

}
